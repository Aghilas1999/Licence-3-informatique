public class Stack {
    private Vector vector = new Vector();

    public void push(int element){
        vector.add(element);
    }

    public boolean isEmpty(){
        return vector.isEmpty();
    }

    public int peek(){
        return vector.get(vector.size()-1);
    }

    public int pop(){
        int element = peek();
        vector.resize(vector.size()-1);
        return element;
    }
}
