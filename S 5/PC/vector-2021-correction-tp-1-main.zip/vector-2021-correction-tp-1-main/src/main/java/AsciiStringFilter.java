public class AsciiStringFilter implements StringFilter{
    @Override
    public String filter(String string) {
        StringBuilder stringBuilder = new StringBuilder();
        for(Character character: string.toCharArray())
            if (character.hashCode()<128)
                stringBuilder.append(character);
        return stringBuilder.toString();
    }
}
