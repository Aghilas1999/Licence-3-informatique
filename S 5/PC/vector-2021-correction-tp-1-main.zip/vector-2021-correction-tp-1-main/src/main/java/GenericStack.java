public class GenericStack<T> {

    private GenericVector<T> vector = new GenericVector<>();

    public void push(T element){
        vector.add(element);
    }

    public boolean isEmpty(){
        return vector.isEmpty();
    }

    public T peek(){
        return vector.get(vector.size()-1);
    }

    public T pop(){
        T element = peek();
        vector.resize(vector.size()-1);
        return element;
    }
}
