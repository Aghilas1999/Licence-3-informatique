public class VerboseVector<T> {
}
