public class StringFilterTools {
    public static String[] filter(StringFilter stringFilter, String... strings){
        for(int index=0; index<strings.length; index++)
            strings[index]=stringFilter.filter(strings[index]);
        return strings;
    }
}
