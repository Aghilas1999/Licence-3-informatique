public class CompositeStringFilter implements StringFilter{
    StringFilter[] stringFilters;

    public CompositeStringFilter(StringFilter[] stringFilters) {
        this.stringFilters = stringFilters;
    }

    @Override
    public String filter(String string) {
        for(StringFilter stringFilter: stringFilters)
            string=stringFilter.filter(string);
        return string;
    }
}
