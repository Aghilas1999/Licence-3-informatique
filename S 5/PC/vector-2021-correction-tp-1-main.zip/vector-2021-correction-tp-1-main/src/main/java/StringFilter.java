public interface StringFilter {
    String filter(String string);
}
