public class PostfixStringFilter implements StringFilter{

    int length;

    public PostfixStringFilter(int length) {
        this.length = length;
    }

    @Override
    public String filter(String string) {
        return string.substring(string.length()-length);
    }
}
