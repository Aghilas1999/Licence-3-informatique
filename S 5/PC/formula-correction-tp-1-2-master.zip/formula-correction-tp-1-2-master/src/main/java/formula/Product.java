package formula;

public class Product implements Formula{
    Formula left,right;

    @Override
    public double asValue() {
        return left.asValue()* right.asValue();
    }

    @Override
    public String asString() {
        return "("+left.asString()+"*"+right.asString()+")";
    }

    public Product(Formula left, Formula right) {
        this.left = left;
        this.right = right;
    }
}
