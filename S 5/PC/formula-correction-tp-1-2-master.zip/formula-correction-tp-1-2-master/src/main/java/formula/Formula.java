package formula;

public interface Formula {
    public double asValue();
    public String asString();
}
