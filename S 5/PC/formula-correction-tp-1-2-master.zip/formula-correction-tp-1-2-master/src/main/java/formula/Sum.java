package formula;

public class Sum implements Formula {
    Formula left, right;

    public Sum(Formula left, Formula right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public double asValue() {
        return left.asValue()+ right.asValue();
    }

    @Override
    public String asString() {
        return "("+left.asString()+"+"+right.asString()+")";
    }
}
