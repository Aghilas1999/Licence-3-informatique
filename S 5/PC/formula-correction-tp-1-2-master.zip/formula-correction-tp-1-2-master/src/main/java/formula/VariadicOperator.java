package formula;

public abstract class VariadicOperator implements Formula {
    Formula[] formulas;

    public VariadicOperator(Formula[] formulas) {
        this.formulas = formulas;
    }

    @Override
    public double asValue() {
        double value = initialValue();
        for (Formula formula : formulas)
            value = cumulativeValue(formula.asValue(), value);
        return value;
    }

    protected abstract double initialValue();

    protected abstract double cumulativeValue(double value, double accumulator);

    @Override
    public String asString() {
        String string = "(" + formulas[0].asString();
        for (int index = 1; index < formulas.length; index++)
            string = string + symbol() + formulas[index].asString();
        return string + ")";
    }

    protected abstract String symbol();
}
