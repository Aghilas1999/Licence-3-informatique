package formula;

public class Square implements Formula {
    Formula formula;
    public Square(Formula formula) {
        this.formula=formula;
    }

    @Override
    public double asValue() {
        return Math.pow(formula.asValue(),2);
    }

    @Override
    public String asString() {
        return formula.asString()+"^2";
    }
}
