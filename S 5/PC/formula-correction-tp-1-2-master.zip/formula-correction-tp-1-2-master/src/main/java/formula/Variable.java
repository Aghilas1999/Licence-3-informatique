package formula;

public class Variable implements Formula {
    String variable;
    double value;

    public Variable(String variable, double value) {
        this.variable = variable;
        this.value = value;
    }

    @Override
    public double asValue() {
        return value;
    }

    @Override
    public String asString() {
        return variable;
    }

    public void setValue(double value) {
        this.value = value;
    }
}
