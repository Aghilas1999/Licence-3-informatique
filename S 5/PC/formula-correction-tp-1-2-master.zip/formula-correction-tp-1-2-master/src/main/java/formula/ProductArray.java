package formula;

public class ProductArray extends VariadicOperator{
    public ProductArray(Formula[] formulas) {
        super(formulas);
    }

    @Override
    protected double initialValue() {
        return 1;
    }

    @Override
    protected double cumulativeValue(double value, double accumulator) {
        return value*accumulator;
    }

    @Override
    protected String symbol() {
        return "*";
    }
}
