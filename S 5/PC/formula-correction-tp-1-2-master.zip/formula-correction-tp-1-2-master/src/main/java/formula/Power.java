package formula;

public class Power {
}
