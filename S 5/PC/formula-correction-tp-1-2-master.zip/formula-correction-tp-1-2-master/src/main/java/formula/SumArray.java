package formula;

public class SumArray extends VariadicOperator {

    public SumArray(Formula[] formulas) {
        super(formulas);
    }

    @Override
    protected double initialValue() {
        return 0;
    }

    @Override
    protected double cumulativeValue(double value, double accumulator){
        return value+accumulator;
    }


    @Override
    protected String symbol() {
        return "+";
    }
}
