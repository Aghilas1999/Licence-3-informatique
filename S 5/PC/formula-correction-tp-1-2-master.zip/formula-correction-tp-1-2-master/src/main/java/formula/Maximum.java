package formula;

public class Maximum implements Formula{
    Formula[] formulas;

    public Maximum(Formula... formulas) {
        this.formulas = formulas;
    }

    @Override
    public double asValue() {
        double max = formulas[0].asValue();
        for(Formula formula: formulas)
            max=Math.max(max,formula.asValue());
        return max;
    }

    @Override
    public String asString() {
        String string = "Maximum("+formulas[0].asString();
        for(int index = 1; index< formulas.length; index++)
            string = string+","+formulas[index].asString();
        return string+")";
    }
}
