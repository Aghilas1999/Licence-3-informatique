package curve;

import java.io.IOException;
import java.io.Writer;

public class Curve {
    Function function;
    double start,end,step;

    public Curve(Function function, double start, double end, double step) {
        this.function = function;
        this.start = start;
        this.end = end;
        this.step = step;
    }

    public void writePoints(Writer writer) throws IOException {
        for(double value = start; value<end;value+=step)
            writer.write(value+" "+ function.eval(value)+"\n");
    }
}
