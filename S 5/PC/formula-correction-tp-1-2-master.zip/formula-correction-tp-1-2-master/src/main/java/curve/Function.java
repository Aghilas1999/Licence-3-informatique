package curve;

import formula.Formula;
import formula.Variable;

public class Function {
   Formula formula;
   Variable variable;

    public Function(Formula formula, Variable variable) {
        this.formula = formula;
        this.variable = variable;
    }

    double eval(double value){
        variable.setValue(value);
        return formula.asValue();
    }
}
